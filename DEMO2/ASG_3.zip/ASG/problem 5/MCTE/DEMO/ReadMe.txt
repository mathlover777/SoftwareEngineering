To RUN:

execute MCTE.jar
or
go to cmd and to the resp. folder

javac *.java press enter
java Start




A demo Test
 
"test0.txt" is given to show how to
give the input file


first line of the file is the total
number of question..here 4

next give the questions,options,correct options as indicated
<question><must be in on line>
<option A><"">
<option B><"">
<option C><"">
<option D><"">
<Correct Option><""><must be in caps>
..........

for example :


"
What is the Capital of India ?
Kolkata
Delhi
Chennai
Mumbai
B
"


Sourav Sarkar
11CS30037