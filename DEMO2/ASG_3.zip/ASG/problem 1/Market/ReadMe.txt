
Please Read This File to Start The Programme SuccessFully

To Run the Programme :

go Via CMD to the dir where the source are kept
and type : "javac *.java" and press Enter

to Run : "java start and press Enter

or Simply start the programme via "ACAD.jar"







The Files -->

baselist.txt
clist.txt
lastucn.txt
lastyearsale.txt
mnagerpass.txt
top10.txt
yearsale.txt

<----

Are necessary to start the programme
Else programme will give filenotfound
exception

also copying these files to 
file directory will reset all database.


.....
.....



Developped By
SS
(Sourav Sarkar)
souravmathlover@gmail.com

2-2-2013

description:




