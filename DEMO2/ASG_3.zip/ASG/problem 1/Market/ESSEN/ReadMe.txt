The Files -->

baselist.txt
clist.txt
lastucn.txt
lastyearsale.txt
mnagerpass.txt
top10.txt
yearsale.txt

<----

Are necessary to start the programme
Else programme will give filenotfound
exception

also copying these files to 
file directory will reset all database.


.....
.....


Manager PassWord : 

"qwerty"


Developped By
SS
(Sourav Sarkar)
souravmathlover@gmail.com

2-2-2013

description:




