

Please Read This File to Start The Programme SuccessFully

To Run the Programme :

go Via CMD to the dir where the source are kept
and type : "javac *.java" and press Enter

to Run : "java Start" and press Enter

or Simply start the programme via "ACAD.jar"



The Files

given in the ESSEN Folder are necessary
to Start the Application

So Place them in the directory
where all the classes of the programme 
are kept

without them we will get FileNotFound
Exceptions....

To Start the programme

run the Class

"Start.class"

<source=Start.java>


***********************Password **************************************************************:

I have used MD5 Hashing while
storing passwords

In case of PassWord Retrival Go to Deans
Page and Click on PassWord Retrieve

type the Login ID
{
	"DEAN"-dean
	"FACAD"-faculty adviser
	Teacher's Name-for Teacher
	Student ID-for Students
}

then Enter the new Password and click
on save

Default Passwords : 

Dean:
login "DEAN"
Password "p"

login "FACAD"
password "p"


In case if DEAN forgets his password...then all password can de resetted by changing directly in "dean_id.txt" file
if new password is "password" ,then find the MD5 Hash of "saltpassword" and replace in place of the old MD5 Hash
password will be reset







