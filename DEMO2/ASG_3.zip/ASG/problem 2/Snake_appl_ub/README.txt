Go TO Bin Folder

start applet.html in a java enabled web browser

if problem with size edit dimension in applet.html file
