

Please Read This File to Start The Programme SuccessFully

To Run the Programme :

go Via CMD to the dir where the source are kept
and type : "javac *.java" and press Enter

to Run : "java Start" and press Enter

or Simply start the programme via "ACAD.jar"



The Files

given in the ESSEN Folder are necessary
to Start the Application

So Place them in the directory
where all the classes of the programme 
are kept

without them we will get FileNotFound
Exceptions....

To Start the programme

run the Class

"Snake.class"

or Simply start the jar file

"SnakesAndLadders.jar"