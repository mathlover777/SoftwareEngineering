

TO run

MULTCLOCK.jar

or comple all and run Clock_Movable.class