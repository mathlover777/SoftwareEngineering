
To Run:

"

<html>

<head>

<title> SNAKE AND LADDER
</title>

</head>

<body>

<applet CODE = "multclock_appl"  WIDTH = 1200  HEIGHT = 800>

</applet>

</body>

</html>

"


please put the above quoted code in a html file ,keep it in the class folder[bin] and run it in a java Enabled Browser

or run the class multclock_appl.class in applet viewer mode from command prompt from bin folder


source is given in the src folder