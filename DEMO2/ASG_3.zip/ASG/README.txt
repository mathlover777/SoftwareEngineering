Starting classes in each of the programmes::

Market:

start.class

Snake:(software)

Snake.class

ACAD:

Start.class


MULTCLOCK:(software)

Clock_Movable.class

MCTE:

Start.class


so if while running the programmes if classes are not found ---- >

"javac *.java"(press enter)
"java xxxx"(press enter).... xxxx=resp Starting class name


I have also tried to provide jar files for :

Market.jar
Snake.jar
acad.jar
clock.jar
MCTE.jar

known issues : these jar files works properly in win7
however acad.jar and MCTE.jar do not behave as expected in UBUNTU[in these cases run from terminal]

But if classes are run from terminal in both windows and ubuntu they are working properly.

the workspace and beta.zip are for backup only

Sourav Sarkar
souravmathlover@gmail.com



