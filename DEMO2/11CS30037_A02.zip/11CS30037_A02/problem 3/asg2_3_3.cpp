/*
 * postfix_eval_with_template.cpp
 *
 *  Created on: Feb 14, 2013
 *      Author: Sourav
 */

//============================================================================
// Name        : postfix_eval.cpp
// Author      :
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
#include "malloc.h"
using namespace std;
class pmm{	
};
class err{	
};
class ovf{	
};
class dbz{	
};
class sne{	
};
template<typename T>
class node {
public:
	T c;
	node *next;
	node() {
		// TODO Auto-generated constructor stub
		T c=0;
		next=0;
	}
	~node() {
		// TODO Auto-generated destructor stub
	}
};


template<typename T> class stack {
private:
	node<T> *head;
public:
	stack() {
		// TODO Auto-generated constructor stub
		head=0;
	}

	void push_stack(T a){
		node<T> *x;
		if(head==0){
			//ie stack is empty
			head=(node<T> *)malloc(sizeof(node<T>));
			(head)->next=0;
		}else{
			x=head;
			head=(node<T> *)malloc(sizeof(node<T>));
			head->next=x;
		}
		head->c=a;
		return;
	}
	int is_empty(){
		if(head==0){
			return 1;
		}
		else{
			return 0;
		}
	}
	T pop_stack(){
		node<T> *temp;
		T c;
		temp=head;
		c=head->c;
		head=head->next;
		free(temp);
		return c;
	}
	T top_stack(){
		return head->c;
	}
	T get_value(){
		return head->c;
	}
	void emptystack(){
	while((*this).is_empty()){
		(*this).pop_stack();
	}
}
	~stack() {
		// TODO Auto-generated destructor stub
	}
};


char *correct(char *x){
	//removing the spaces
	int i=0,j=0;
	char *a=new char[100];
	char *c=new char[100];
	a[0]='0';
	a[1]='+';
	j=2;
	while(x[i]!='\0'){
		//cout<<"\nx["<<i<<"] = "<<x[i];
		if(x[i]==32){
			//cout<<"\nspace";
			i++;
			continue;
		}else{
			a[j]=x[i];
			j++;
			i++;
			continue;
		}
	}
	a[j]=x[i];
	//cout<<endl<<a;
	//spaces are removed
	//modifying for uninary + and -
	i=0;j=1;
	c[0]=a[0];
	while(1){
		if(a[i+1]!='\0'){
			if(a[i]=='+'||a[i]=='-'||a[i]=='*'||a[i]=='/'||a[i]=='('){
				//sign detected at i
				if(a[i+1]=='+'){
					//got a uninary + replacing it with (0+1)*
					c[j]='(';
					//cout<<c[j];
					j++;
					c[j]='0';
					//cout<<c[j];
					j++;
					c[j]='+';
					//cout<<c[j];
					j++;
					c[j]='1';
					//cout<<c[j];
					j++;
					c[j]=')';
					//cout<<c[j];
					j++;
					c[j]='*';
					//cout<<c[j];
					j++;
					i++;
					continue;
				}
				if(a[i+1]=='-'){
				//got a uninary + replacing it with (0+1)*
					c[j]='(';
					//cout<<c[j];
					j++;
					c[j]='0';
					//cout<<c[j];
					j++;
					c[j]='-';
					//cout<<c[j];
					j++;
					c[j]='1';
					//cout<<c[j];
					j++;
					c[j]=')';
					//cout<<c[j];
					j++;
					c[j]='*';
					//cout<<c[j];
					j++;
					i++;
					continue;
				}
				if(a[i+1]=='*'||a[i+1]=='/'){
					//cout<<"error detected ...";
					delete[] a;
					delete[] c;
					//return 0;
					throw err();
				}
				c[j]=a[i+1];
				j++;
				i++;
				continue;
			}
			else{
				if(a[i]==')'&&a[i+1]=='('){
					c[j]='*';
					j++;
					c[j]='(';
					j++;
					c[j]='0';
					j++;
					c[j]='+';
					j++;
					c[j]='1';
					j++;
					c[j]=')';
					j++;
					c[j]='*';
					j++;
				}
				c[j]=a[i+1];
				//cout<<c[j];
				j++;
				i++;
				continue;
			}
		}
		else{
			c[j]=a[i+1];
			//cout<<c[j];
			break;
		}
	}
	delete[] a;
	return c;
}



int give_precedence(char c){
	switch(c){
		case '*':{
			return 3;
		}
		case '/':{
			return 3;
		}
		case '+':{
			return 2;
		}
		case '-':{
			return 2;
		}
		default:{
			cout<<endl<<"INVALID OPERATOR !!!";
			return 0;
		}
	}
}
char *infix_to_postfix(char *s){
	char *x;
	x=new char[200];
	stack<int> num,op,temp;
	int i=0;
	char c;
	while(s[i]!='\0'){
		if(((s[i]>=48)&&(s[i]<=57))||(s[i]==' '))//we got a part of a number
		{
			num.push_stack(s[i]);
		}
		if(s[i]=='+'||s[i]=='-'||s[i]=='*'||s[i]=='/'){
			num.push_stack(' ');
			while(1){
				if(!op.is_empty()){
					c=op.top_stack();
					if(c=='('){
						break;
					}
					if(give_precedence(s[i])<=give_precedence(c)){
						c=op.pop_stack();
						num.push_stack(c);
						num.push_stack(' ');
					}else{
						break;
					}
				}else{
					break;
				}
			}
			op.push_stack(s[i]);
		}
		if(s[i]=='('){
			num.push_stack(' ');
			op.push_stack(s[i]);
		}
		if(s[i]==')'){
			num.push_stack(' ');
			while(1){
				if(op.is_empty()){
					throw pmm();
					//return NULL;
				}
				c=op.pop_stack();
				if(c=='('){
					break;
				}
				num.push_stack(c);
				num.push_stack(' ');
			}
		}
		i++;
		if(i==100){
			throw ovf();
			//return NULL;
		}
	}
	num.push_stack(' ');
	while(1){
		if(!op.is_empty()){
			c=op.pop_stack();
			if(c=='('||c==')'){
				throw pmm();
				//return NULL;
			}
			num.push_stack(c);
			num.push_stack(' ');
		}else{
			break;
		}
	}
	int flag=0;
	while(1){
		if(num.is_empty()){
			break;
		}
		c=num.pop_stack();
		if(c==' '){
			if(flag==0){
				temp.push_stack(' ');
				flag=1;
			}
		}else{
			flag=0;
			temp.push_stack(c);
		}
	}
	i=0;
	while(1){
		if(temp.is_empty()){
			break;
		}
		c=temp.pop_stack();
		x[i]=c;
		i++;
		if(i==200){
			throw ovf();
			//cout<<endl<<"OVERFLOW INTERNAL !!!";
			//return NULL;
		}
	}
	x[i]='\0';
	return x;
}
int postfix_to_value(char *x){
	//cout<<"ew43243";
	int i=0,n,m,v;
	stack<int> s;
	if(x[i]==' ') i++;
	while(x[i]!='\0'){
		if(x[i]!='+'&&x[i]!='-'&&x[i]!='*'&&x[i]!='/'){
			n=0;
			while(x[i]!=' '&&x[i]!='\0'){
				n=n*10+x[i]-48;
				i++;
			}
			s.push_stack(n);
			i++;
			if(x[i]=='\0'){
				break;
			}
		}else{
			//cout<<"Going to check stack !!";
			if(s.is_empty()){
				//cout<<"Stack empty";
				//throw error();
				return 0;
			}
			n=s.pop_stack();
			if(s.is_empty()){
				//cout<<"stack empty";
				//throw error();
				return 0;
			}
			m=s.pop_stack();
			switch(x[i]){
				case '+':{
					s.push_stack(m+n);
					break;
				}
				case '-':{
					s.push_stack(m-n);
					break;
				}
				case '*':{
					s.push_stack(m*n);
					break;
				}
				case '/':{
					if(n==0){
						s.emptystack();
						cout<<"\nDivision By Zero !!! ";
						throw dbz();
						//return 0;
					}
					s.push_stack(m/n);
					break;
				}
			}
			i=i+2;
			if(x[i]=='\0'){
				break;
			}
		}
	}
	v=s.top_stack();
	s.pop_stack();
	if(s.is_empty()){
		return v;
	}else{
		s.emptystack();
		//cout<<"\nStack Not Empty !!! Error In Input";
		throw sne();
		return 0;
	}
}

int main(){
	char s[100],*x,*p;
	int v;
	cout<<"Enter Expression : ";
	cin.getline(s,100);
	try{
		x=correct(s);
	}catch(err &ee){
		cout<<"\nUnknown Error !!";
		return 0;
	}
	cout<<endl<<"Modified Expression:"<<endl<<x<<endl;
	try{
		p=infix_to_postfix(x);
	}catch(err &ee){
		cout<<"\nUnknown Error !!! Exiting...";
		return 0;
	}catch(pmm &ee){
		cout<<"\nParrenthesis Missmatch !!";
		return 0;
	}catch(ovf &ee){
		cout<<"\ninput Too large to process !!";
		return 0;
	}
	cout<<endl<<"Post Fix Expression : "<<endl<<p;
	try{
		v=postfix_to_value(p);
	}catch(dbz &ee){
		cout<<"\nDivide By Zero !!";
		return 0;
	}catch(sne &ee){
		cout<<"\nStack Not Empty ...  Incorrrect Expression !!";
		return 0;
	}catch(err &ee){
		cout<<"\nUnknown Error !!";
		return 0;
	}
	cout<<endl<<"Result : "<<v<<endl;
	return 0;
}




