//============================================================================
// Name        : postfix_eval.cpp
// Author      : 
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
#include <stack>
using namespace std;
class pmm{	
};
class err{	
};
class ovf{	
};
class dbz{	
};
class sne{	
};
char *correct(char *x){
	//removing the spaces
	int i=0,j=0;
	char *a=new char[100];
	char *c=new char[100];
	a[0]='0';
	a[1]='+';
	j=2;
	while(x[i]!='\0'){
		//cout<<"\nx["<<i<<"] = "<<x[i];
		if(x[i]==32){
			//cout<<"\nspace";
			i++;
			continue;
		}else{
			a[j]=x[i];
			j++;
			i++;
			continue;
		}
	}
	a[j]=x[i];
	//cout<<endl<<a;
	//spaces are removed
	//modifying for uninary + and -
	i=0;j=1;
	c[0]=a[0];
	while(1){
		if(a[i+1]!='\0'){
			if(a[i]=='+'||a[i]=='-'||a[i]=='*'||a[i]=='/'||a[i]=='('){
				//sign detected at i
				if(a[i+1]=='+'){
					//got a uninary + replacing it with (0+1)*
					c[j]='(';
					//cout<<c[j];
					j++;
					c[j]='0';
					//cout<<c[j];
					j++;
					c[j]='+';
					//cout<<c[j];
					j++;
					c[j]='1';
					//cout<<c[j];
					j++;
					c[j]=')';
					//cout<<c[j];
					j++;
					c[j]='*';
					//cout<<c[j];
					j++;
					i++;
					continue;
				}
				if(a[i+1]=='-'){
				//got a uninary + replacing it with (0+1)*
					c[j]='(';
					//cout<<c[j];
					j++;
					c[j]='0';
					//cout<<c[j];
					j++;
					c[j]='-';
					//cout<<c[j];
					j++;
					c[j]='1';
					//cout<<c[j];
					j++;
					c[j]=')';
					//cout<<c[j];
					j++;
					c[j]='*';
					//cout<<c[j];
					j++;
					i++;
					continue;
				}
				if(a[i+1]=='*'||a[i+1]=='/'){
					//cout<<"error detected ...";
					delete[] a;
					delete[] c;
					//return 0;
					throw err();
				}
				c[j]=a[i+1];
				j++;
				i++;
				continue;
			}
			else{
				if(a[i]==')'&&a[i+1]=='('){
					c[j]='*';
					j++;
					c[j]='(';
					j++;
					c[j]='0';
					j++;
					c[j]='+';
					j++;
					c[j]='1';
					j++;
					c[j]=')';
					j++;
					c[j]='*';
					j++;
				}
				c[j]=a[i+1];
				//cout<<c[j];
				j++;
				i++;
				continue;
			}
		}
		else{
			c[j]=a[i+1];
			//cout<<c[j];
			break;
		}
	}
	delete[] a;
	return c;
}
int give_precedence(char c){
	switch(c){
		case '*':{
			return 3;
		}
		case '/':{
			return 3;
		}
		case '+':{
			return 2;
		}
		case '-':{
			return 2;
		}
		default:{
			cout<<endl<<"ERROR in input invalid operator ...";
			return 0;
		}
	}
}
char *infix_to_postfix(char *s){
	char *x;
	x=new char[200];
	stack<int> num,op,temp;
	int i=0;
	char c;
	while(s[i]!='\0'){
		if(((s[i]>=48)&&(s[i]<=57))||(s[i]==' '))//we got a part of a number
		{
			num.push(s[i]);
		}
		if(s[i]=='+'||s[i]=='-'||s[i]=='*'||s[i]=='/'){
			num.push(' ');
			while(1){
				if(!op.empty()){
					c=op.top();
					if(c=='('){
						break;
					}
					if(give_precedence(s[i])<=give_precedence(c)){
						c=op.top();
						op.pop();
						num.push(c);
						num.push(' ');
					}else{
						break;
					}
				}else{
					break;
				}
			}
			op.push(s[i]);
		}
		if(s[i]=='('){
			num.push(' ');
			op.push(s[i]);
		}
		if(s[i]==')'){
			num.push(' ');
			while(1){
				if(op.empty()){
					throw pmm();
					//return NULL;
				}
				c=op.top();
				op.pop();
				if(c=='('){
					break;
				}
				num.push(c);
				num.push(' ');
			}
		}
		i++;
		if(i==100){
			throw ovf();
			//return NULL;
		}
	}
	num.push(' ');
	while(1){
		if(!op.empty()){
			c=op.top();
			op.pop();
			if(c=='('||c==')'){
				throw pmm();
				//return NULL;
			}
			num.push(c);
			num.push(' ');
		}else{
			break;
		}
	}
	int flag=0;
	while(1){
		if(num.empty()){
			break;
		}
		c=num.top();
		num.pop();
		if(c==' '){
			if(flag==0){
				temp.push(' ');
				flag=1;
			}
		}else{
			flag=0;
			temp.push(c);
		}
	}
	i=0;
	while(1){
		if(temp.empty()){
			break;
		}
		c=temp.top();
		temp.pop();
		x[i]=c;
		i++;
		if(i==200){
			throw ovf();
			//cout<<endl<<"OVERFLOW(INTERNAL)";
			//return NULL;
		}
	}
	x[i]='\0';
	return x;
}
int postfix_to_value(char *x){
	int i=0,n,m;
	stack<int> s;
	if(x[i]==' ') i++;
	while(x[i]!='\0'){
		if(x[i]!='+'&&x[i]!='-'&&x[i]!='*'&&x[i]!='/'){
			n=0;
			while(x[i]!=' '&&x[i]!='\0'){
				n=n*10+x[i]-48;
				i++;
			}
			s.push(n);
			i++;
			if(x[i]=='\0'){
				break;
			}
		}else{
			if(s.empty()){
				throw err();
				//cout<<endl<<"ERROR in input...";
				//return 0;
			}
			n=s.top();
			s.pop();
			if(s.empty()){
				throw err();
				//cout<<endl<<"ERROR in input...";
				//return 0;
			}
			m=s.top();
			s.pop();
			switch(x[i]){
				case '+':{
					s.push(m+n);
					break;
				}
				case '-':{
					s.push(m-n);
					break;
				}
				case '*':{
					s.push(m*n);
					break;
				}
				case '/':{
					if(n==0){
						throw dbz();
						//cout<<"\nDivision By Zero !!! ";
						//return 0;
					}
					s.push(m/n);
					break;
				}
			}
			i=i+2;
			if(x[i]=='\0'){
				break;
			}
		}
	}
	int	v=s.top();
	s.pop();
	if(s.empty()){
		return v;
	}else{
		throw sne();
		//cout<<"\nStack Not Empty !!! Error In Input";
		//return 0;
	}
}
int main(){
	char s[100],*x,*p;
	int v;
	cout<<"Enter Expression : ";
	cin.getline(s,100);
	try{
		x=correct(s);
	}catch(err &ee){
		cout<<"\nUnknown Error !!";
		return 0;
	}
	cout<<endl<<"Modified Expression:"<<endl<<x<<endl;
	try{
		p=infix_to_postfix(x);
	}catch(err &ee){
		cout<<"\nUnknown Error !!! Exiting...";
		return 0;
	}catch(pmm &ee){
		cout<<"\nParrenthesis Missmatch !!";
		return 0;
	}catch(ovf &ee){
		cout<<"\ninput Too large to process !!";
		return 0;
	}
	cout<<endl<<"Post Fix Expression : "<<endl<<p;
	try{
		v=postfix_to_value(p);
	}catch(dbz &ee){
		cout<<"\nDivide By Zero !!";
		return 0;
	}catch(sne &ee){
		cout<<"\nStack Not Empty ...  Incorrrect Expression !!";
		return 0;
	}catch(err &ee){
		cout<<"\nUnknown Error !!";
		return 0;
	}
	cout<<endl<<"Result : "<<v<<endl;
	return 0;
}



