#include <stdio.h>
#include <stdlib.h>
/*********************Integer STACK****************************/
struct node{
	int c;
	struct node *next;
};
typedef struct node node;
struct stack{
	node *head;
};
typedef struct stack stack;
/*************************stack functions*********************/
void initialise_stack(stack *a){
	a->head=NULL;
}
void push_stack(stack *q,int a){
	node *x;
	if(q->head==NULL){
		//ie stack is empty
		q->head=(node *)malloc(sizeof(node));
		(q->head)->next=NULL;
	}else{
		x=q->head;
		q->head=(node *)malloc(sizeof(node));
		q->head->next=x;
	}
	q->head->c=a;
	return;
}
int is_empty(stack *q){
	if(q->head==NULL){
		return 1;
	}
	else{
		return 0;
	}
}
int pop_stack(stack *q){
	node *temp;
	int c;
	temp=q->head;
	c=q->head->c;
	q->head=q->head->next;
	free(temp);
	return c;
}
int top_stack(stack *q){
	return q->head->c;
}
/*******************************************************/
char *correct(char *x){
	//removing the spaces
	int i=0,j=0;
	char *a=(char *)malloc(sizeof(char)*100);
	char *c=(char *)malloc(sizeof(char)*100);
	a[0]='0';
	a[1]='+';
	j=2;
	while(x[i]!='\0'){
		//cout<<"\nx["<<i<<"] = "<<x[i];
		if(x[i]==32){
			//cout<<"\nspace";
			i++;
			continue;
		}else{
			a[j]=x[i];
			j++;
			i++;
			continue;
		}
	}
	a[j]=x[i];
	//cout<<endl<<a;
	//spaces are removed
	//modifying for uninary + and -
	i=0;j=1;
	c[0]=a[0];
	while(1){
		if(a[i+1]!='\0'){
			if(a[i]=='+'||a[i]=='-'||a[i]=='*'||a[i]=='/'||a[i]=='('){
				//sign detected at i
				if(a[i+1]=='+'){
					//got a uninary + replacing it with (0+1)*
					c[j]='(';
					//cout<<c[j];
					j++;
					c[j]='0';
					//cout<<c[j];
					j++;
					c[j]='+';
					//cout<<c[j];
					j++;
					c[j]='1';
					//cout<<c[j];
					j++;
					c[j]=')';
					//cout<<c[j];
					j++;
					c[j]='*';
					//cout<<c[j];
					j++;
					i++;
					continue;
				}
				if(a[i+1]=='-'){
				//got a uninary + replacing it with (0+1)*
					c[j]='(';
					//cout<<c[j];
					j++;
					c[j]='0';
					//cout<<c[j];
					j++;
					c[j]='-';
					//cout<<c[j];
					j++;
					c[j]='1';
					//cout<<c[j];
					j++;
					c[j]=')';
					//cout<<c[j];
					j++;
					c[j]='*';
					//cout<<c[j];
					j++;
					i++;
					continue;
				}
				if(a[i+1]=='*'||a[i+1]=='/'){
					//cout<<"error detected ...";
				 	free(a);
					free(c);
					return NULL;
					//throw error();
				}
				c[j]=a[i+1];
				j++;
				i++;
				continue;
			}
			else{
				if(a[i]==')'&&a[i+1]=='('){
					c[j]='*';
					j++;
					c[j]='(';
					j++;
					c[j]='0';
					j++;
					c[j]='+';
					j++;
					c[j]='1';
					j++;
					c[j]=')';
					j++;
					c[j]='*';
					j++;
				}
				c[j]=a[i+1];
				//cout<<c[j];
				j++;
				i++;
				continue;
			}
		}
		else{
			c[j]=a[i+1];
			//cout<<c[j];
			break;
		}
	}
	free(a);
	return c;
}


int give_precedence(char c){
	switch(c){
		case '*':{
			return 3;
		}
		case '/':{
			return 3;
		}
		case '+':{
			return 2;
		}
		case '-':{
			return 2;
		}
	}	
}
char *infix_to_postfix(char *s){
	char *x;
	x=(char *)malloc(sizeof(char)*200);
	stack num,op,temp;
	initialise_stack(&num);
	initialise_stack(&op);
	initialise_stack(&temp);
	int i=0;
	char c;
	while(s[i]!='\0'){
		if((s[i]>=48)&&(s[i]<=57)||(s[i]==' '))//we got a part of a number
		{
			push_stack(&num,s[i]);	
		}
		if(s[i]=='+'||s[i]=='-'||s[i]=='*'||s[i]=='/'){
			push_stack(&num,' ');
			while(1){
				if(!is_empty(&op)){
					c=top_stack(&op);
					if(c=='('){
						break;
					}
					if(give_precedence(s[i])<=give_precedence(c)){
						c=pop_stack(&op);
						push_stack(&num,c);
						push_stack(&num,' ');
					}else{
						break;
					}
				}else{
					break;
				}
			}
			push_stack(&op,s[i]);
		}
		if(s[i]=='('){
			push_stack(&num,' ');
			push_stack(&op,s[i]);
		}
		if(s[i]==')'){
			push_stack(&num,' ');
			while(1){
				if(is_empty(&op)){
					return NULL;
				}
				c=pop_stack(&op);
				if(c=='('){
					break;
				}
				push_stack(&num,c);
				push_stack(&num,' ');
			}	
		}
		i++;
		if(i==100){
			return NULL;
		}
	}
	push_stack(&num,' ');
	while(1){
		if(!is_empty(&op)){
			c=pop_stack(&op);
			if(c=='('||c==')'){
				return NULL;
			}
			push_stack(&num,c);
			push_stack(&num,' ');
		}else{
			break;
		}
	}
	int flag=0;
	while(1){
		if(is_empty(&num)){
			break;
		}
		c=pop_stack(&num);
		if(c==' '){
			if(flag==0){
				push_stack(&temp,' ');
				flag=1;
			}
		}else{
			flag=0;
			push_stack(&temp,c);
		}
	}
	i=0;
	while(1){
		if(is_empty(&temp)){
			break;
		}
		c=pop_stack(&temp);
		x[i]=c;
		i++;
		if(i==200){
			printf("\nOVERFLOW(INTERNAL) !!! ");
			return NULL;
		}
	}
	x[i]='\0';
	return x;
}
int postfix_to_value(char *x){
	int i=0,n,m,v;
	stack s;
	initialise_stack(&s);
	if(x[i]==' ') i++;
	while(x[i]!='\0'){
		if(x[i]!='+'&&x[i]!='-'&&x[i]!='*'&&x[i]!='/'){
			n=0;
			while(x[i]!=' '&&x[i]!='\0'){
				n=n*10+x[i]-48;
				i++;
			}
			push_stack(&s,n);
			i++;
			if(x[i]=='\0'){
				break;
			}			
		}else{
			if(is_empty(&s)){
				printf("\nERROR in input...");
				return 0;
			}
			n=pop_stack(&s);
			if(is_empty(&s)){
				printf("\nERROR in input...");
				return 0;
			}
			m=pop_stack(&s);
			switch(x[i]){
				case '+':{
					push_stack(&s,m+n);
					break;
				}
				case '-':{
					push_stack(&s,m-n);
					break;
				}
				case '*':{
					push_stack(&s,m*n);
					break;
				}
				case '/':{
					if(n==0){
						printf("\nDivision By Zero !!! ");
						return 0;
					}
					push_stack(&s,m/n);
					break;
				}
			}
			i=i+2;
			if(x[i]=='\0'){
				break;
			}
		}	
	}
	v=s.head->c;
	pop_stack(&s);
	if(!is_empty(&s)){
		printf("\nStack Not Empty !!! Error In Input");
		return 0;
	}
	return v;
}
int main(){
	char s[100],*x,*m;
	printf("\nEnter Your String : \n");
	scanf("%[^\n]",s);
	m=correct(s);
	if(m==NULL){
		printf("\nFATAL ERROR in INPUT...");
		return 0;
	}
	printf("\nNew Modified Expression : \n%s",m);
	x=infix_to_postfix(m);
	if(x==NULL){
		printf("\nFATAL ERROR in INPUT...");
		return 0;
	}
	printf("\nPOST FIX EXPRESSION : \n\n%s\n\n",x);
	int v;
	v=postfix_to_value(x);
	printf("\nvalue : %d ",v);
	free(m);
	free(x);
	return 0;
}
