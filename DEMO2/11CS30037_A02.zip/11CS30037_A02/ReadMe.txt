All Source files are given in the folder
in case of any issue
please mail : souravmathlover@gmail.com

problem 3(infix to postfix)

all 4 programmes are written as independent files[4 subproblems 4 sources each containing main]
so to run complile the required and run

problem 2(b) is written in mulifile

for c version (part 1): 
compile qdsolver_c.c

for c++ version (part 2):
compile qd_solver_with_exception.cpp [contains main]


for problem 1:

complie calculator.cpp[its with main]

complex class written in Complex.cpp and Complex.h




all the above programmes are tested in mingw5
 


And Q/A given in Software Engineering Q.pdf file
