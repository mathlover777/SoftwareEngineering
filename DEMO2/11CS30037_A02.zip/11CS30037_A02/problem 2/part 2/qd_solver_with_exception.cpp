/*
 * qd_solver_with_exception.cpp
 *
 *  Created on: Feb 14, 2013
 *      Author: Sourav
 */
#include <iostream>
#include <cmath>
#include "Complex.h"
using namespace std;

/*************************EXCEPTIONS************************************************************************/
class linear_exception{
	string s;
public:
	linear_exception(){
		s="Leading Coefficient is Zero !!! Only One root found !!...";
	}
	void print_msg(){
		cout<<endl<<s;
	}
};
class invalid_exception{
	string s;
public:
	invalid_exception(){
		s="Both The Coefficients of X^2 and X are 0 ,,invalid Expression";
	}
	void print_msg(){
		cout<<endl<<s;
	}
};
class imagineryroots_exception{
	string s;
public:
	imagineryroots_exception(){
			s="Discriminant is negative...Found two distinct Complex roots !!";
	}
	void print_msg(){
		cout<<endl<<s;
	}
};
class equalroots_exception{
	string s;
public:
	equalroots_exception(){
		s="Discriminant is 0...Found two same real roots !!";
	}
	void print_msg(){
		cout<<endl<<s;
	}
};
/**********************************EXCEPTIONS END HERE**********************************************************/
void qdsolver(double a,double b,double c,Complex *r)
{
	if((a==0.0)&&(b==0.0))
	{
		throw invalid_exception();
	}
	if((a==0.0))
	{
		Complex x(-1*c/b,0);
		r[0]=x;
		throw linear_exception();
	}
	double d2;
	d2=b*b-4*a*c;
	if(d2<0.0)
	{
		Complex x(-b/(2*a),sqrt(-1*d2)/(2*a));
		Complex y(-b/(2*a),-1*sqrt(-1*d2)/(2*a));
		r[0]=x;
		r[1]=y;
		throw imagineryroots_exception();

	}
	if(d2==0){
		Complex x(-b/(2*a),0);
		r[0]=x;
		r[1]=x;
		throw equalroots_exception();
	}
	Complex x(-b/(2*a)+sqrt(1*d2)/(2*a));
	Complex y(-b/(2*a)-1*sqrt(1*d2)/(2*a));
	r[0]=x;
	r[1]=y;
	return;
}



int main(){
	double a,b,c;
	cout<<"ENTER VALUE OF a = :";
	cin>>a;
	cout<<"ENTER VALUE OF b = :";
	cin>>b;
	cout<<"ENTER VALUE OF c = :";
	cin>>c;


	Complex r[2];


	try{
		qdsolver(a,b,c,r);
		cout<<endl<<"Two distinct real roots found !!";
		cout<<endl<<"ROOT 1 : "<<r[0]<<"\tROOT 2 : "<<r[1];

	}catch(invalid_exception &ee){
		ee.print_msg();
	}catch(linear_exception &ee){
		ee.print_msg();
		cout<<endl<<"ROOT : "<<r[0];
	}catch(equalroots_exception &ee){
		ee.print_msg();
		cout<<endl<<"ROOT : "<<r[0];
	}catch(imagineryroots_exception &ee){
		ee.print_msg();
		cout<<endl<<"ROOT 1 : "<<r[0]<<"\tROOT 2 : "<<r[1];
	}
	cout<<endl<<endl;
	return 0;
}
