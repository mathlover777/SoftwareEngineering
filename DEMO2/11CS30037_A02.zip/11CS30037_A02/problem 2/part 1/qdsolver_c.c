/*
 * qdsolver_c.c
 *
 *  Created on: Feb 8, 2013
 *      Author: Sourav
 */

#include <stdio.h>
#include <setjmp.h>
#include <math.h>
struct complex{
	double re,im;
};
typedef struct complex complex;
struct roots{
	complex r1,r2;
};
typedef struct roots roots;

void qdsolver(double a,double b,double c,jmp_buf buffer,roots *r);

int main(){
	double a,b,c;
	jmp_buf buffer;
	printf("\nEnter Value of a : ");
	scanf("%lf",&a);
	printf("\nEnter Value of b : ");
	scanf("%lf",&b);
	printf("\nEnter Value of c : ");
	scanf("%lf",&c);


	roots r;
	switch(setjmp(buffer))
	{
	case 0:{
		//this is same as the try step
		qdsolver(a,b,c,buffer,&r);
		printf("\nEquation Successfully solved\n and different real roots obtained: ");
		printf("\nRoot 1 : %lf",r.r1.re);
		printf("\nRoot 2 : %lf",r.r2.re);
		break;
	}
	//case values >=1 represents exceptions
	case 1:{
		printf("\nSorry a=0 and b=0 ,\nIts not a valid quadratic equation...");
		break;
	}
	case 2:{
		printf("\na=0 means its a linear equation...\nOne real root found...");
		printf("\nRoot : %lf",r.r1.re);
		break;
	}
	case 3:{
		printf("\nDiscriminant is negative...\nTwo imaginary roots found !!!");
		printf("\nRoot 1 : (%lf)+i(%lf)",r.r1.re,r.r1.im);
		printf("\nRoot 2 : (%lf)+i(%lf)",r.r2.re,r.r2.im);
		break;
	}
	case 4:{
		printf("\nDiscriminant is zero...So real double root found !!!");
		printf("\nRoot : %lf",r.r1.re);
		break;
	}
	}
	printf("\n\n");
	return 0;
}

void qdsolver(double a,double b,double c,jmp_buf buffer,roots *r)
{
	(r->r1).re=0;
	(r->r1).im=0;
	(r->r2).re=0;
	(r->r2).im=0;

	if((a==0.0)&&(b==0.0))
	{
		longjmp(buffer,1);
	}
	if((a==0.0))
	{
		(r->r1).re=-1*c/b;
		(r->r1).im=0;
		longjmp(buffer,2);
	}
	double d2;
	d2=b*b-4*a*c;
	if(d2<0.0)
	{
		(r->r1).re=-b/(2*a);
		(r->r1).im=sqrt(-1*d2)/(2*a);
		(r->r2).re=-b/(2*a);
		(r->r2).im=-1*sqrt(-1*d2)/(2*a);
		longjmp(buffer,3);
	}
	if(d2==0){
		(r->r1).re=-b/(2*a);
		(r->r1).im=0;
		(r->r2).re=-b/(2*a);
		(r->r2).im=0;
		longjmp(buffer,4);
	}
	(r->r1).re=(-b+sqrt(d2))/(2*a);
	(r->r1).im=0;
	(r->r2).re=(-b-sqrt(d2))/(2*a);
	(r->r2).im=0;
	return;
}
