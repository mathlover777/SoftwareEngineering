/*
 * dividebyzero.cpp
 *
 *  Created on: Feb 14, 2013
 *      Author: Sourav
 */

#include "dividebyzero.h"

divide_by_zero::divide_by_zero(){
		s="Dividing By Zero Exception !!!";
}
void divide_by_zero::getmsg(){
		cout<<endl<<s;
		return;
}
divide_by_zero::~divide_by_zero() {
	// TODO Auto-generated destructor stub
}

