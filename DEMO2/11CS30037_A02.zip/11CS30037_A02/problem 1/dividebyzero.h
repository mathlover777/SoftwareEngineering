/*
 * dividebyzero.h
 *
 *  Created on: Feb 14, 2013
 *      Author: Sourav
 */
#include <iostream>
using namespace std;
#ifndef DIVIDEBYZERO_H_
#define DIVIDEBYZERO_H_

class divide_by_zero {
	string s;
public:
	divide_by_zero();
	void getmsg();
	virtual ~divide_by_zero();
};

#endif /* DIVIDEBYZERO_H_ */
