/*
 * originexception.cpp
 *
 *  Created on: Feb 14, 2013
 *      Author: Sourav
 */

#include "originexception.h"

origin_exception::origin_exception() {
	// TODO Auto-generated constructor stub
	s="Argument of Origin is not Defined...";
}
void origin_exception::getmsg(){
	cout<<endl<<s;
}
origin_exception::~origin_exception() {
	// TODO Auto-generated destructor stub
}

