/*
 * calculator.cpp
 *
 *  Created on: Feb 14, 2013
 *      Author: Sourav
 */
#include <iostream>
#include "Complex.h"
#include "dividebyzero.h"
using namespace std;
int main(){
	int i,flag;
	i=1;
	Complex a,b,c;
	while(1){
		cout<<"\nWelcome to Complex Calculator ";
		cout<<"\n\tEnter 0 to exit";
		cout<<"\n\tEnter 1 to store value in A";
		cout<<"\n\tEnter 2 to store value in B";
		cout<<"\n\tEnter 3 to find A+B";
		cout<<"\n\tEnter 4 to find A-B";
		cout<<"\n\tEnter 5 to find A*B";
		cout<<"\n\tEnter 6 to find A/B";
		cout<<"\n\tEnter 7 to find Complement of A";
		cout<<"\n\tEnter 8 to find Complement of B";
		cout<<"\n\tEnter 9 to represent of A,B,C in Norm-Argument Form";
		cout<<"\nAll result except argument will be stored in C";
		cout<<"\n\tEnter Choice : ";
		cin>>i;
		flag=1;
		switch(i){
		case 0:{
			break;
		}case 1:{
			cout<<"\n\tEnter value of A : ";
			cin>>a;
			break;
		}case 2:{
			cout<<"\n\tEnter value of B : ";
			cin>>b;
			break;
		}case 3:{
			c=a+b;
			break;
		}case 4:{
			c=a-b;
			break;
		}case 5:{
			c=a*b;
			break;
		}case 6:{
			try{
				c=a/b;
			}catch(divide_by_zero &ee){
				ee.getmsg();
				flag=0;
			}
			break;
		}case 7:{
			c=!a;
			break;
		}case 8:{
			c=!b;
			break;
		}
		case 9:{
			try{
				cout<<"\nNorm(A) : "<<*a;
				cout<<"\tArg(A) : "<<a.arg();
			}catch(origin_exception &ee){
				cout<<"\nCant get argument of a";
				ee.getmsg();
			}
			try{
				cout<<"\nNorm(B) : "<<*b;
				cout<<"\tArg(B) : "<<b.arg();
			}catch(origin_exception &ee){
				cout<<"\nCant get argument of b";
				ee.getmsg();
			}
			try{
				cout<<"\nNorm(C) : "<<*c;
				cout<<"\tArg(C) : "<<c.arg();
			}catch(origin_exception &ee){
				cout<<"\nCant get argument of c";
				ee.getmsg();
			}
			flag=0;
			break;
		}
		}
		if(i==0) break;
		if(flag==1){
			cout<<"\nA = "<<a<<" B = "<<b<<" C= "<<c;
		}
	}
	return 0;
}

