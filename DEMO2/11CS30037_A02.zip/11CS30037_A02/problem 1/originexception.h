/*
 * originexception.h
 *
 *  Created on: Feb 14, 2013
 *      Author: Sourav
 */
#include <iostream>
using namespace std;
#ifndef ORIGINEXCEPTION_H_
#define ORIGINEXCEPTION_H_

class origin_exception {
	string s;
public:
	origin_exception();
	void getmsg();
	virtual ~origin_exception();
};

#endif /* ORIGINEXCEPTION_H_ */
