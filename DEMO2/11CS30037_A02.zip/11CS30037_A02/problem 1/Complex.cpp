/*
 * Complex.cpp
 *
 *  Created on: Feb 8, 2013
 *      Author: Sourav
 */

#include "Complex.h"


Complex::Complex(double r, double i){
	// TODO Auto-generated constructor stub
	re_=r;
	im_=i;
}

Complex::Complex(const Complex&x){
	re_=x.re_;
	im_=x.im_;
}
Complex& Complex::operator=(const Complex&x){
	re_=x.re_;
	im_=x.im_;
	return *this;
}
Complex Complex::operator+(const Complex&x){
	Complex r;
	r.re_=re_+x.re_;
	r.im_=im_+x.im_;
	return r;
}
Complex Complex::operator-(const Complex&x){
	Complex r;
	r.re_=re_-x.re_;
	r.im_=im_-x.im_;
	return r;
}
Complex Complex::operator*(const Complex&x){
	Complex r;
	r.re_=(re_*x.re_)-(im_*x.im_);
	r.im_=(re_*x.im_)+(im_*x.re_);
	return r;
}
Complex Complex::operator/(const Complex&x){
	Complex r;
	double k;
	k=(x.re_*x.re_)+(x.im_+x.im_);
	if(k==0){
		throw divide_by_zero();
	}
	r.re_=((re_*x.re_)+(im_*x.im_))/k;
	r.im_=((re_*x.im_)-(im_*x.re_))/k;
	return r;
}
Complex Complex::operator/(double d){
	Complex r;
	if(d==0){
		throw divide_by_zero();
	}
	r.re_=re_/d;
	r.im_=im_/d;
	return r;
}
Complex Complex::operator+(){
	Complex r;
	r.re_=this->re_;
	r.im_=this->im_;
	return r;
}
Complex Complex::operator-(){
	Complex r;
	r.re_=(-1)*(this->re_);
	r.im_=(-1)*(this->im_);
	return r;
}
Complex& Complex::operator--(){
	re_--;
	return *this;
}
Complex& Complex::operator++(){
	re_++;
	return *this;
}
Complex Complex::operator--(int dummy){
	im_--;
	return *this;
}
Complex Complex::operator++(int dummy){
	im_++;
	return *this;
}
bool Complex::operator==(const Complex&x){
	if(x.im_==this->im_&&x.re_==this->re_) return true;
	return false;
}
bool Complex::operator!=(const Complex&x){
	if(x.im_==this->im_&&x.re_==this->re_) return false;
	return true;
}
bool Complex::operator<(const Complex&x){
	double n1,n2;
	n2=*x;
	n1=*(*this);
	if(n1<n2) return true;
	return false;
}
bool Complex::operator<=(const Complex&x){
	double n1,n2;
	n2=*x;
	n1=*(*this);
	if(n1<=n2) return true;
	return false;
}
bool Complex::operator>(const Complex&x){
	double n1,n2;
	n2=*x;
	n1=*(*this);
	if(n1>n2) return true;
	return false;
}
bool Complex::operator>=(const Complex&x){
	double n1,n2;
	n2=*x;
	n1=*(*this);
	if(n1>=n2) return true;
	return false;
}
Complex& Complex::operator+=(const Complex&x){
	this->re_=this->re_+x.re_;
	this->im_=this->im_+x.im_;
	return *this;
}
Complex& Complex::operator-=(const Complex&x){
	this->re_=this->re_-x.re_;
	this->im_=this->im_-x.im_;
	return *this;
}
Complex& Complex::operator*=(const Complex&x){
	this->re_=(re_*x.re_)-(im_*x.im_);
	this->im_=(re_*x.im_)+(im_*x.re_);
	return *this;
}
Complex& Complex::operator/=(const Complex&x){
	double k;
	k=(x.re_*x.re_)+(x.im_+x.im_);
	if(k==0){
			throw divide_by_zero();
		}
	re_=((re_*x.re_)+(im_*x.im_))/k;
	im_=((re_*x.im_)-(im_*x.re_))/k;
	return *this;
}
Complex const& Complex::operator[](unsigned int i) const{
	return *(this+i);
}
Complex& Complex::operator[](unsigned int i){
	return *(this+i);
}
double Complex::operator*() const{
	double m;
	m=sqrt((re_*re_)+(im_*im_));
	return m;
}
Complex Complex::operator!() const{
	Complex r;
	r.re_=re_;
	r.im_=(-1)*(im_);
	return r;
}
ostream& operator<<(ostream& os, const Complex& r){
	os<<'('<<r.re_<<")+i("<<r.im_<<')';
	return os;
}
istream& operator>>(istream& is, Complex& r){
	is>>r.re_;
	is>>r.im_;
	return is;
}
void* Complex::operator new(size_t s){
	void *ptr;
	ptr=malloc(s);
	return ptr;
}
void Complex::operator delete(void *ptr){
	free(ptr);
}
static const Complex sc_cUnityR(1.0,0.0);			// Defines 1+j0
static const Complex sc_cUnityI(0.0,1.0);			// Defines 0+j1
static const Complex sc_cZero(0.0,0.0);				// Defines 0+j0
double Complex::GetReal(){
	return re_;
}
double Complex::GetImg(){
	return im_;
}
double Complex::arg(){
	double pi=3.14159265359;
	if(re_==0&&im_==0){
		throw origin_exception();
	}
	if(re_==0){
		if(im_>0) return (pi/2);
		else return (-1*(pi/2));
	}
	if(re_>0){
		return atan(im_/re_);
	}
	if(im_>0){
		return ((pi/2)-atan(im_/re_));
	}
	if(im_<0){
		return ((-1*(pi/2))-atan(im_/re_));
	}
	if(re_<0&&im_>0){
		return (pi+atan(im_/re_));
	}
	if(re_<0&&im_<0){
		return (((-1)*pi)+atan(im_/re_));
	}
	return atan(im_/re_);
}
Complex::~Complex() {
	// TODO Auto-generated destructor stub
}

